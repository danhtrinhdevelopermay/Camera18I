package com.iosCamera.ios_camera_flutter_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
