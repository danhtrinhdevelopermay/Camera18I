# Camera181 - Flutter iOS 18 Camera App

Native Android camera application mimicking iOS 18 interface with Gaussian blur effects, built with Flutter.

## 🎯 Project Focus

This project is a **Flutter native Android app** that provides:
- Real iOS 18-style camera interface
- Native Android permission dialogs
- Direct camera access without web layer
- APK build automation via GitHub Actions

## 📱 Features

- 📸 **Native Camera Interface** - Flutter camera plugin for direct hardware access
- 🎨 **iOS 18 Design** - Blur effects and frosted glass styling
- 🔒 **Real Permissions** - Native Android permission dialogs
- ⚡ **Performance** - No web layer, pure Flutter performance
- 🤖 **Auto Build** - GitHub Actions for APK generation

## 🛠 Tech Stack

- **Framework**: Flutter
- **Language**: Dart
- **Platform**: Android (native)
- **Camera**: Flutter camera plugin
- **Permissions**: permission_handler plugin
- **Build**: GitHub Actions CI/CD

## 📁 Project Structure

```
ios_camera_flutter_app/
├── lib/
│   ├── main.dart           # App entry point
│   ├── screens/            # UI screens
│   └── widgets/            # Reusable components
├── android/                # Android-specific configuration
├── pubspec.yaml            # Dependencies and configuration
└── build-apk.sh           # Build script
```

## 🚀 Build APK

### Automated Build (GitHub Actions)
Push to `main` branch and GitHub Actions will automatically:
1. Setup Flutter environment
2. Build release APK
3. Upload as artifact

### Manual Build
```bash
cd ios_camera_flutter_app
flutter pub get
flutter build apk --release
```

APK location: `build/app/outputs/flutter-apk/app-release.apk`

## 📋 APK vs Web App Comparison

| Feature | Flutter App | Web App |
|---------|------------|---------|
| Permission Dialogs | ✅ Native Android | ❌ Only in APK build |
| Camera Access | ✅ Direct hardware | 🔄 Via getUserMedia |
| Performance | ✅ Native speed | ⚠️ WebView layer |
| Installation | 📱 APK file | 🌐 Browser only |

## 🔧 Development

### Prerequisites
- Flutter SDK
- Android Studio
- Android SDK (API 34)

### Setup
```bash
git clone https://github.com/danhtrinhdevelopermay/Camera181.git
cd Camera181/ios_camera_flutter_app
flutter pub get
flutter run
```

## 📱 Testing

1. **Development**: Use `flutter run` for testing
2. **APK Build**: Build APK and install on Android device
3. **Permissions**: Test camera permissions on real device

## 🎉 Success Proof

✅ **Confirmed Working Features:**
- Native Android permission dialogs appear on app startup
- Camera preview starts immediately after granting permissions  
- iOS 18-style UI with blur effects
- Touch controls and camera functionality
- APK builds successfully via GitHub Actions

## 🔄 GitHub Actions

The `.github/workflows/build-android.yml` handles:
- Flutter setup
- Dependency installation
- APK compilation (debug + release)
- Artifact upload

## 🎯 Mission Accomplished

This project proves that **Flutter native apps can trigger real Android permission dialogs** immediately, unlike web apps which only show permissions when built as APK.

## 📄 License

MIT License - Built for demonstrating Flutter camera capabilities with iOS 18 styling.