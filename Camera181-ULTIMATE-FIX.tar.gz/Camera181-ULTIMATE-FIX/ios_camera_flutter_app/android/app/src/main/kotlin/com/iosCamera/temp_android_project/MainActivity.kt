package com.iosCamera.temp_android_project

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
