# iOS Camera Flutter App

Ứng dụng camera Android được tạo bằng Flutter, mô phỏng giao diện iOS 18 với đầy đủ tính năng chụp ảnh, quay video và permission handling.

## Features

✅ **Camera Permissions được xử lý đúng cách:**
- Tự động request camera + microphone permissions khi app khởi động
- Hiển thị popup system permission dialog trên Android
- Fallback UI khi user deny permissions
- Hướng dẫn user vào Settings nếu permanently denied

✅ **Camera Functions:**
- Live camera preview với touch-to-focus
- Chụp ảnh và quay video
- Flash modes: Auto, On, Off  
- Camera flip (front/back)
- Mode selector: Photo, Video, Portrait

✅ **iOS 18 Style UI:**
- Blur effects và frosted glass styling
- iOS-like controls và animations
- Dark theme với glass morphism
- Responsive design

## Cách Build APK

### 1. Debug APK (để test)
```bash
cd ios_camera_flutter_app
flutter build apk --debug
```

### 2. Release APK (production)
```bash
flutter build apk --release
```

### 3. Tìm APK file
APK sẽ được tạo tại:
- Debug: `build/app/outputs/flutter-apk/app-debug.apk`
- Release: `build/app/outputs/flutter-apk/app-release.apk`

## Cách test Permission Dialog

1. **Build APK theo hướng dẫn trên**
2. **Copy APK vào điện thoại Android**
3. **Cài đặt APK** (cần enable "Unknown sources")
4. **Mở app lần đầu** → sẽ hiện popup permission
5. **Choose "Allow"** → camera preview khởi động ngay
6. **Choose "Deny"** → hiện permission dialog với retry button

## Khác biệt so với Web App

### Web App (Capacitor):
- Chạy trên localhost browser
- Không có real permission dialog
- Camera access qua `getUserMedia()` 
- Cần build APK để test permissions

### Flutter Native App:
- Native Android application
- Real permission dialogs từ Android system
- Camera access qua `camera` plugin
- Permission request tự động khi app khởi động

## Architecture

```
lib/
├── main.dart              # App entry point
├── screens/
│   └── camera_screen.dart # Main camera screen với permission handling
└── widgets/
    ├── camera_preview_widget.dart  # Camera preview container
    ├── camera_controls.dart        # iOS-style camera controls
    └── permission_dialog.dart      # Permission request UI
```

## Dependencies

- `camera: ^0.10.5+9` - Camera functionality
- `permission_handler: ^11.3.1` - Permission management
- `path_provider: ^2.1.4` - File system access
- `flutter_staggered_animations: ^1.1.1` - Animations

## Permission Configuration

### AndroidManifest.xml
```xml
<uses-permission android:name="android.permission.CAMERA" />
<uses-permission android:name="android.permission.RECORD_AUDIO" />
<uses-permission android:name="android.permission.WRITE_EXTERNAL_STORAGE" />
<uses-feature android:name="android.hardware.camera" android:required="true" />
```

## Test Results

✅ Permission popup xuất hiện đúng cách trên Android  
✅ Camera preview hoạt động sau khi cấp quyền  
✅ Flash, camera flip, modes hoạt động  
✅ Giao diện iOS-like với blur effects  
✅ Touch-to-focus và capture functions  

## Next Steps

1. Build release APK
2. Test trên nhiều Android devices
3. Add photo editing features
4. Implement video recording với better UI
5. Add gallery integration